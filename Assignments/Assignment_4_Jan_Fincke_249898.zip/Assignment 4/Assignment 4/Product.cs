﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4
{
    class Product
    {
        public string Name;
        public decimal Prices;

        public Product(string Name, int Prices)
        {
            this.Name = Name;
            this.Prices = Prices;
        }
    }
}
