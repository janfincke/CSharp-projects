﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            ColorPack MyColorPack = new ColorPack();
            foreach (string ColorName in MyColorPack)
            {
                Console.WriteLine(ColorName);
            }

        }
    }
}
