﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wincubate.Module08.Data
{
    public class Administrator : Participant
    {
        public Administrator()
            : base(
                "Gabriel",
                "Nis",
                "Teknologisk" )
        {
        }
   }
}
