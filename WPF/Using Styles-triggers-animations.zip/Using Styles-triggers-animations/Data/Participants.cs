﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Wincubate.Module08.Data
{
    public class Participants : ObservableCollection<Participant>
    {
        public Participants()
        {
            this.Add( new Participant( "Gulmann Henriksen",
                                       "Jesper",
                                       "Wincubate",
                                       new Uri( "pack://application:,,,/Wincubate.Module08.Data;component/JGH.jpg" ) ) );
            this.Add( new Participant( "Albrink",
                                       "Thomas",
                                       "Nokia Danmark A/S" ) );
            this.Add( new Participant( "Kjær",
                                       "Danny",
                                       "A-Data A/S" ) );
            this.Add( new Participant( "Broge Richelsen",
                                       "Mads",
                                       "Burmeister & Wain Scandinavian Contractor A/S" ) );
            this.Add( new Participant( "Kuyucu",
                                       "Ismail",
                                       "Forsikringens DataCenter" ) );
            this.Add( new Participant( "Hvitved",
                                       "Michael A.",
                                       "Forsikringens DataCenter" ) );
            this.Add( new Participant( "Værlund",
                                       "Jesper",
                                       "KMD A/S" ) );
            this.Add( new Administrator() );
        }

        public Participants( int number )
        {
            for( int i = 0; i < number; i++ )
            {
                this.Add( new Participant( "Deltagersen",
                                          "Deltager" + i,
                                          "Virksomhed",
                                          new Uri( "pack://application:,,,/Wincubate.Module08.Data;component/nophoto.gif" ) ) );
            }
        }

        public Participants CloneFirst( int number )
        {
            Participants clone = new Participants();
            clone.Clear();
            foreach( var p in this.Take( number ) )
            {
                clone.Add( p );
            }

            return clone;
        }
    }
}
