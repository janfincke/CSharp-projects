﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;

namespace Wincubate.Module04.Slide10
{
   public class SpStyleSelector : StyleSelector
   {
      public Style NormalReleaseStyle
      {
         get;
         set;
      }
      public Style ServicePackStyle
      {
         get;
         set;
      }

      public SpStyleSelector()
      {
         // Create a normal release style
         Style style = new Style();
         Setter setter = new Setter();
         setter.Property = Control.BackgroundProperty;
         setter.Value = Brushes.Cornsilk;
         style.Setters.Add( setter );

         NormalReleaseStyle = style;

         // Create service pack style
         Style style2 = new Style();
         Setter setter2 = new Setter();
         setter2.Property = Control.ForegroundProperty;
         setter2.Value = Brushes.WhiteSmoke;
         style2.Setters.Add( setter2 );
         Setter setter3 = new Setter();
         setter3.Property = Control.BackgroundProperty;
         setter3.Value = Brushes.Black;
         style2.Setters.Add( setter3 );

         ServicePackStyle = style2;
      }

      public override Style SelectStyle( object item, DependencyObject container )
      {
         string dotnetrelease = item.ToString();
         if( dotnetrelease.Contains( "SP" ) )
         {
            return ServicePackStyle;
         }

         return NormalReleaseStyle;
      }
   }
}
